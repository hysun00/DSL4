close all;
name1 = readimage("Haoyuan.jpg");
name2 = readimage("Yichen.jpg");
name3 = readimage("Lushan.jpg");

tiledlayout(3, 1);
nexttile;
imshow(~name1);
nexttile;
imshow(~name2);
nexttile;
imshow(~name3);

Name = [name1; name2; name3];
Name = [Name, zeros(120, 160-53)];
figure;
imshow(~Name);

fileID = fopen("VGA_INIT.txt", "w");
for i = 1:120
    for j = 1:160
        if Name(i, j)
            fprintf(fileID, "@0x%X\t0x%d\n", (i-1)*16^2+(j-1), Name(i, j));
        end
    end
end
fclose(fileID);

function I = readimage(filename)
I = rgb2gray(imread(filename)) < 145;
I(~any(I, 2), :) = [];
I(:, ~any(I, 1)) = [];
I = Resize(I);
end

function I = Resize(Image)
final_size1 = 40;
final_size2 = 53;
Size = size(Image);
I = [false(floor((final_size1 - Size(1))/2), Size(2)); Image; false(ceil((final_size1 - Size(1))/2), Size(2))];
I = [false(final_size1, floor((final_size2 - Size(2))/2)), I, false(final_size1, ceil((final_size2 - Size(2))/2))];
end