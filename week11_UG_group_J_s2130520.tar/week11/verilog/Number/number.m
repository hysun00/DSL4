% https://onlinenumbertools.com/convert-numbers-to-image 70 50 18
zero = readimage("0.jpg");
one = readimage("1.jpg");
two = readimage("2.jpg");
three = readimage("3.jpg");
four = readimage("4.jpg");
five = readimage("5.jpg");
six = readimage("6.jpg");
seven = readimage("7.jpg");
eight = readimage("8.jpg");
nine = readimage("9.jpg");
quotation = rgb2gray(imread("quotation.jpg")) < 128;
quotation(:, ~any(quotation, 1)) = [];
quotation = quotation(15:45, :);
quotation = Resize(quotation);

tiledlayout(1, 11);
nexttile;
imshow(~zero);
nexttile;
imshow(~one);
nexttile;
imshow(~two);
nexttile;
imshow(~three);
nexttile;
imshow(~four);
nexttile;
imshow(~five);
nexttile;
imshow(~six);
nexttile;
imshow(~seven);
nexttile;
imshow(~eight);
nexttile;
imshow(~nine);
nexttile;
imshow(~quotation);

%%
fileID = fopen("Numbers_VGA_RAM.txt", "w");
for i = 1:44
    for j = 1:31
        fprintf(fileID, "%d%d%d%d%d%d%d%d%d%d%d\n", quotation(i, j), nine(i, j), eight(i, j), seven(i, j), six(i, j), five(i, j), four(i, j), three(i, j), two(i, j), one(i, j), zero(i, j));
    end
end
fclose(fileID);

%%
function I = readimage(filename)
I = rgb2gray(imread(filename)) < 128;
I(~any(I, 2), :) = [];
I(:, ~any(I, 1)) = [];
I = Resize(I);
end

function I = Resize(Image)
final_size1 = 44;
final_size2 = 31;
Size = size(Image);
I = [false(floor((final_size1 - Size(1))/2), Size(2)); Image; false(ceil((final_size1 - Size(1))/2), Size(2))];
I = [false(final_size1, floor((final_size2 - Size(2))/2)), I, false(final_size1, ceil((final_size2 - Size(2))/2))];
end